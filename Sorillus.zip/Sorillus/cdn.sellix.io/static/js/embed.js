var initializeSellixEmbed = function () {
    if(!document.getElementById("sellix-container")) {
        var sellixContainerElem = document.createElement("div");
        sellixContainerElem.setAttribute("id", "sellix-container");
        document.body.appendChild(sellixContainerElem);
    }

    if(!document.getElementById("sellix-buttons-pointers-fix")) {
        var pointerFix = document.createElement("div");
        pointerFix.setAttribute("id", "sellix-buttons-pointers-fix");
        pointerFix.innerHTML = "<style>[data-sellix-product] * { pointer-events: none; } [data-sellix-group] * { pointer-events: none; }</style>";
        document.getElementById("sellix-container").appendChild(pointerFix);
    }

    var productButtons = document.querySelectorAll("[data-sellix-product]");
    var groupButtons = document.querySelectorAll("[data-sellix-group]");
    var cartButtons = document.querySelectorAll("[data-sellix-cart]");

    setTimeout(function waiter(repeat) {
        var hasProduct = document.querySelector("[data-sellix-product]");
        var hasGroup = document.querySelector("[data-sellix-group]");
        var hasCart = document.querySelector("[data-sellix-cart]");

        if ((hasProduct || hasGroup || hasCart) && !repeat) {
            var customStyles = document.getElementById("sellix-css");

            var onClickProduct = function (e, type) {
                var ID = '670211fa219bb'; // Produkt-ID ersetzt

                var customFields = "?";
                var attributes = e.target.attributes;

                for (var i = 0; i < attributes.length; i++) {
                    let currentAttribute = attributes[i];
                    if (currentAttribute.nodeName.indexOf("data-sellix-css") > -1) {
                        customFields += "css=" + currentAttribute.nodeValue + "&";
                    }
                }

                if (customStyles && !(customFields.indexOf('css=') > -1)) {
                    customFields += "css=" + customStyles.href;
                }

                var link = "https://embed.sellix.io/product/" + ID + customFields; // Embed-Link aktualisiert
                var fallbackButton = '<div class="sellix-fallback-button-container"><a class="sellix-fallback-button" href="' + link + '" target="_blank" >Go to product</a></div>';

                var sellixModalElem = document.createElement("div");
                sellixModalElem.setAttribute("id", "sellix-modal-" + ID);
                sellixModalElem.setAttribute("style", "display:none; position:fixed; top: 0; left:0; width: 100%; height:100%; z-index:1050");

                sellixModalElem.innerHTML =
                    '<div id="backdrop" class="sellix-backdrop"></div>' +
                    '<style>' +
                    '.sellix-iframe-loader { animation-name: spin; animation-duration: 2s; animation-iteration-count: 5; animation-timing-function: ease-in-out; width: 35px !important; height: 35px !important; }' +
                    '@keyframes spin { 0% { transform: rotate(0deg); } 50% { transform: rotate(360deg); } 100% { transform: rotate(360deg); } }' +
                    '.sellix-iframe-placeholder { z-index: 1; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); margin: 0 auto; width: 500px; height: 600px; border-radius: 16px; background-size: 200%; background-position: left; animation-duration: 1.7s; animation-fill-mode: forwards; animation-iteration-count: infinite; animation-timing-function: linear; animation-name: placeholderAnimate; background: #f6f7f8; background: linear-gradient(to right, rgb(238 238 238 / 10%) 2%, rgb(221 221 221 / 20%) 18%, rgb(238 238 238 / 10%) 33%, rgb(238 238 238) 100%); box-shadow: 0 0 30px rgba(0, 0, 0, 0.1); }' +
                    '@keyframes placeholderAnimate { 0% { background-position: 200% 0; } 100% { background-position: 0 0; } }' +
                    '</style>' +
                    '<div class="sellix-iframe-placeholder">' +
                    '<div class="sellix-iframe-loader"></div>' +
                    '</div>' +
                    '<iframe id="sellix-embed-iframe" src="' + link + '" frameborder="0" scrolling="no" style="width: 100%; height: 100%; border-radius: 16px; z-index: 1050; position: relative;"></iframe>' +
                    '<div class="sellix-fallback-button-container">' + fallbackButton + '</div>';

                document.getElementById("sellix-container").appendChild(sellixModalElem);

                document.getElementById("backdrop").addEventListener("click", function () {
                    document.getElementById("sellix-modal-" + ID).remove();
                });

                document.getElementById("sellix-modal-" + ID).style.display = "block";
            };

            for (var i = 0; i < productButtons.length; i++) {
                let productButton = productButtons[i];
                productButton.addEventListener("click", function (e) {
                    onClickProduct(e, "product");
                });
            }

            for (var i = 0; i < groupButtons.length; i++) {
                let groupButton = groupButtons[i];
                groupButton.addEventListener("click", function (e) {
                    onClickProduct(e, "group");
                });
            }

        } else {
            setTimeout(function() {
                waiter(true);
            }, 500);
        }
    }, 500);
};

window.onload = initializeSellixEmbed;
